import React from 'react'

const Support = () => {
  return (
    
<>
<h1 className='text-center p-9 text-[50px]'>Welcome to Support</h1>
<div className='p-5'>
  
 <form className='form-control my-3'>   
   <input type="text" className='form-control my-3' placeholder='Enter your question' />
   <input type="number" className='form-control my-3' placeholder='Enter your Number' />
   <button className=' form-control my-3 bg-slate-500'> Submit</button>
   </form>
</div>
</>
  )
}

export default Support