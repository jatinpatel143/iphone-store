import React from 'react'
import Iphone from '../assets/new.jpg'

const Herosection = () => {
  return (
   <div className="countainer p-4 w-auto ">
    
    <img src={Iphone} alt="" />
     
   </div>
  )
}

export default Herosection